import React, { Component } from 'react';
//import logo from './logo.svg';
//mport './App.css';
import web3 from './web3';
import Crowdsale from './Crowdsale';
import { Progress } from 'semantic-ui-react'

class App extends Component {
  state = {
    price: '',
    fundingGoal: '',
    balance: '',
    value: '',
    percent: '',
    address:'',
    priceETH:'',
    amountRaised:'',
    amountRaisedETH:''
  }
  async componentDidMount() {
    const price = await Crowdsale.methods.price().call();
    const priceETH = await web3.utils.fromWei(price);
    const fundingGoal = await Crowdsale.methods.fundingGoal().call();
    const fundingGoalETH= await web3.utils.fromWei(fundingGoal);
    const amountRaised = await Crowdsale.methods.amountRaised().call();
    const amountRaisedETH = await web3.utils.fromWei(amountRaised);
    const balance = await web3.eth.getBalance(Crowdsale.options.address);
    const percent = await (amountRaised/fundingGoal)*100;
    //const deadline = await Crowdsale.methods.deadline().call();
    //const whitlist = await Crowdsale.methods.authorized().call();

    this.setState({ price, priceETH, fundingGoal, balance, amountRaisedETH, percent, fundingGoalETH });     
  }

  //Our current price per token in Ethereum is: {this.state.priceETH}<br/>
  //The funding goal for the current Crowdsale is: {this.state.fundingGoalETH} Ethereum.<br/>
  //Curnnent amount raised: {this.state.amountRaisedETH} Ethereum


  render() {
    return (
        <div>
          
          <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.12/semantic.min.css"></link>
          <Progress percent={this.state.percent} color='teal' size = "medium"  progress precision = '0'/><br/>

          
        </div>  

    );
  }
}

export default App;
